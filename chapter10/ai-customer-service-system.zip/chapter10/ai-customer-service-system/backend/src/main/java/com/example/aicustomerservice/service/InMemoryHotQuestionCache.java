package com.example.aicustomerservice.service;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 热点问题缓存。
 *
 * 生产环境通常放到共享缓存，并设置 TTL。这里用内存 Map 表达“高频 FAQ 不必每次请求模型”的设计。
 */
public class InMemoryHotQuestionCache implements HotQuestionCache {

    private final Map<String, String> cache = new ConcurrentHashMap<>();

    @Override
    public Optional<String> get(String cacheKey) {
        return Optional.ofNullable(cache.get(cacheKey));
    }

    @Override
    public void put(String cacheKey, String answer) {
        cache.put(cacheKey, answer);
    }
}
