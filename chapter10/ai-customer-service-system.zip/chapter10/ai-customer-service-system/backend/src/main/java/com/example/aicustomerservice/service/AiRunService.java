package com.example.aicustomerservice.service;

import com.example.aicustomerservice.ai.ModelSettings;
import com.example.aicustomerservice.common.BusinessException;
import com.example.aicustomerservice.dao.AiRunDao;
import com.example.aicustomerservice.entity.AiRunAudit;
import com.example.aicustomerservice.entity.SupportDecision;
import java.time.Instant;
import java.util.List;

/** AI 编排审计服务，把运行中的复杂对象转换成可安全展示、可长期保存的摘要。 */
public class AiRunService {

    private final AiRunDao aiRunDao;

    public AiRunService(AiRunDao aiRunDao) {
        this.aiRunDao = aiRunDao;
    }

    public AiRunAudit record(
        String requestId,
        String conversationId,
        ModelSettings settings,
        SupportDecision decision,
        long elapsedMs,
        Instant createdAt
    ) {
        AiRunAudit run = new AiRunAudit(
            requestId,
            conversationId,
            settings.provider().name(),
            settings.modelName(),
            decision.intent().type().name(),
            decision.intent().confidence(),
            decision.sources().stream()
                .map(source -> "%s@%s %s score=%.3f".formatted(
                    source.documentId(), source.version(), source.title(), source.score()
                ))
                .toList(),
            decision.toolTraces().stream()
                .map(tool -> tool.toolName() + "：" + tool.summary())
                .toList(),
            decision.guardrails().stream()
                .map(guardrail -> guardrail.problem().name() + "：" + guardrail.action())
                .toList(),
            elapsedMs,
            decision.handoffRequired(),
            createdAt
        );
        return aiRunDao.save(run);
    }

    public List<AiRunAudit> search(String conversationId, Boolean handoff, int limit) {
        return aiRunDao.search(conversationId, handoff, Math.max(1, Math.min(limit, 200)));
    }

    public AiRunAudit get(String requestId) {
        return aiRunDao.findByRequestId(requestId)
            .orElseThrow(() -> new BusinessException("AI_RUN_NOT_FOUND", "AI 运行记录不存在：" + requestId));
    }
}
