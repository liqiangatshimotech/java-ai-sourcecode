package com.example.aicustomerservice.controller;

import com.example.aicustomerservice.ai.ModelSettings;
import com.example.aicustomerservice.dto.CustomerSupportRequest;
import com.example.aicustomerservice.dto.CustomerSupportResponse;
import com.example.aicustomerservice.dto.RuntimeResponse;
import com.example.aicustomerservice.service.AiRunService;
import com.example.aicustomerservice.service.CustomerSupportService;
import jakarta.validation.Valid;
import java.time.Clock;
import java.time.Instant;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/support")
public class CustomerSupportController {

    private static final Logger log = LoggerFactory.getLogger(CustomerSupportController.class);

    private final CustomerSupportService supportService;
    private final AiRunService aiRunService;
    private final ModelSettings modelSettings;
    private final String storageType;
    private final Clock clock;

    public CustomerSupportController(
        CustomerSupportService supportService,
        AiRunService aiRunService,
        ModelSettings modelSettings,
        @Value("${support.storage.type:postgres}") String storageType,
        Clock clock
    ) {
        this.supportService = supportService;
        this.aiRunService = aiRunService;
        this.modelSettings = modelSettings;
        this.storageType = storageType;
        this.clock = clock;
    }

    @GetMapping("/runtime")
    public RuntimeResponse runtime() {
        return RuntimeResponse.from(modelSettings, storageType);
    }

    @PostMapping("/chat")
    public ResponseEntity<CustomerSupportResponse> chat(
        @RequestHeader(value = "X-Request-Id", required = false) String inboundRequestId,
        @Valid @RequestBody CustomerSupportRequest request
    ) {
        Instant receivedAt = clock.instant();
        long startNanos = System.nanoTime();
        String requestId = normalizeRequestId(inboundRequestId);
        var decision = supportService.handle(
            request.sessionId(),
            request.customerId(),
            request.question(),
            request.orderNo()
        );
        long elapsedMs = (System.nanoTime() - startNanos) / 1_000_000;

        // 审计失败不应该吞掉已经生成的客服回复；记录告警后仍把业务结果返回给前端。
        try {
            aiRunService.record(
                requestId,
                request.sessionId(),
                modelSettings,
                decision,
                elapsedMs,
                receivedAt
            );
        } catch (RuntimeException exception) {
            log.warn("support.chat audit failed requestId={} reason={}", requestId, exception.getMessage());
        }

        log.info(
            "support.chat requestId={} customerId={} sessionId={} intent={} handoff={} elapsedMs={}",
            requestId,
            request.customerId(),
            request.sessionId(),
            decision.intent().type(),
            decision.handoffRequired(),
            elapsedMs
        );

        return ResponseEntity.ok()
            .header("X-Request-Id", requestId)
            .body(CustomerSupportResponse.from(decision, requestId, receivedAt, elapsedMs));
    }

    private String normalizeRequestId(String inboundRequestId) {
        if (inboundRequestId != null && !inboundRequestId.isBlank()) {
            return inboundRequestId.trim();
        }
        return "REQ-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
}
