package com.example.aicustomerservice.service;

import com.example.aicustomerservice.ai.ChatModelClient;
import com.example.aicustomerservice.ai.SupportPrompt;
import com.example.aicustomerservice.entity.CustomerTier;
import com.example.aicustomerservice.entity.IntentType;
import com.example.aicustomerservice.entity.ModelCallResult;
import com.example.aicustomerservice.entity.ModelTier;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 模型请求队列入口。
 *
 * 真实线上环境会把这层做成限流队列、线程池、熔断和降级策略。
 * 这里保留 queueDepth 和 tier，方便在接口和测试里看到高并发治理的设计。
 */
public class QueuedModelExecutor {

    private final ChatModelClient chatModelClient;
    private final int maxImmediateRequests;
    private final AtomicInteger inFlight = new AtomicInteger();

    public QueuedModelExecutor(ChatModelClient chatModelClient, int maxImmediateRequests) {
        this.chatModelClient = chatModelClient;
        this.maxImmediateRequests = maxImmediateRequests;
    }

    public ChatModelClient client() {
        return chatModelClient;
    }

    public ModelCallResult generate(SupportPrompt prompt) {
        int queueDepth = inFlight.incrementAndGet();
        boolean queued = queueDepth > maxImmediateRequests;
        try {
            return new ModelCallResult(
                chatModelClient.generate(prompt),
                tier(prompt),
                queued,
                queueDepth
            );
        } finally {
            inFlight.decrementAndGet();
        }
    }

    private ModelTier tier(SupportPrompt prompt) {
        if (prompt.customer().tier() == CustomerTier.ENTERPRISE || prompt.intent().type() == IntentType.REFUND) {
            return ModelTier.ESCALATED;
        }
        if (prompt.intent().type() == IntentType.FAQ && !prompt.knowledge().isEmpty()) {
            return ModelTier.FAST;
        }
        return ModelTier.STANDARD;
    }
}
