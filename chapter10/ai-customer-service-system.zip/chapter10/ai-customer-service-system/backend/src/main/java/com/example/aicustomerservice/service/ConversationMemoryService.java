package com.example.aicustomerservice.service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 会话记忆服务。
 *
 * 这里保存的是客服会话摘要，不保存无限长的聊天全文。生产系统要避免把所有历史消息
 * 原样塞进模型上下文，否则成本和延迟都会失控。
 */
public class ConversationMemoryService {

    private final Map<String, List<String>> summaries = new ConcurrentHashMap<>();

    public void append(String sessionId, String question, String answer) {
        List<String> sessionSummaries = summaries.computeIfAbsent(sessionId, ignored -> new ArrayList<>());
        sessionSummaries.add(Instant.now() + " Q: " + question + " A: " + answer);
        if (sessionSummaries.size() > 5) {
            sessionSummaries.remove(0);
        }
    }

    public List<String> recentSummaries(String sessionId) {
        return List.copyOf(summaries.getOrDefault(sessionId, List.of()));
    }
}
